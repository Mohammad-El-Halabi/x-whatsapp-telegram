@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

echo ========== Deploying Signal Staff Control ==========
echo.

:: Step 1: Build the exe if not already built
if not exist "dist\Signal Staff Control.exe" (
    echo [1/3] Building exe...
    call build.bat
    if errorlevel 1 exit /b 1
) else (
    echo [1/3] Exe already built, skipping.
)

:: Step 2: Create deployment folder
set DEPLOY_DIR=deploy\Signal Staff Control
if exist "!DEPLOY_DIR!" (
    rmdir /s /q "!DEPLOY_DIR!"
)
mkdir "!DEPLOY_DIR!"
echo [2/3] Created deploy folder.

:: Step 3: Copy files
echo [3/3] Copying files...
copy "dist\Signal Staff Control.exe" "!DEPLOY_DIR!" >nul
copy "logo.webp" "!DEPLOY_DIR!" >nul
copy "icon.ico" "!DEPLOY_DIR!" >nul
copy "Create Shortcut.bat" "!DEPLOY_DIR!" >nul
(
echo SUPABASE_URL=https://wghpuytsnjldzysxnrpm.supabase.co
echo SUPABASE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndnaHB1eXRzbmpsZHp5c3hucnBtIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODIyMjQxMzcsImV4cCI6MjA5NzgwMDEzN30.muwy7Ou9GnOrM7HssnfA2mueJti10159zoMg9rnjKjE
echo SUPABASE_SERVICE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndnaHB1eXRzbmpsZHp5c3hucnBtIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc4MjIyNDEzNywiZXhwIjoyMDk3ODAwMTM3fQ.UYQPzTaQ9kdrqjMqixRsTl2E6RxgsnNniXDZs4Yl-_A
echo SIGNAL_CLI_PATH=signal-cli\bin\signal-cli.bat
echo JAVA_HOME=C:\Program Files\Java\jdk-25.0.2
) > "!DEPLOY_DIR!\.env"
xcopy "C:\Users\pc\Downloads\signal-cli-master\signal-cli-master\build\install\signal-cli" "!DEPLOY_DIR!\signal-cli" /E /I /Q >nul

rem Remove unwanted files from signal-cli
if exist "!DEPLOY_DIR!\signal-cli\bin\signal-cli" del "!DEPLOY_DIR!\signal-cli\bin\signal-cli" 2>nul

echo.
echo ========== Deploy Complete ==========
echo.
echo Output folder: %cd%\!DEPLOY_DIR!
echo.
echo Total size:
powershell -Command "(Get-ChildItem -Recurse '!DEPLOY_DIR!' | Measure-Object -Property Length -Sum).Sum / 1MB | ForEach-Object { '{0:N2} MB' -f $_ }"
echo.
echo To distribute, zip the folder: !DEPLOY_DIR!
echo.
echo User instructions:
echo   1. Install Java JDK 25
echo   2. Set JAVA_HOME environment variable
echo   3. Edit .env with actual keys
echo   4. Run Signal Staff Control.exe
echo ====================================
pause
